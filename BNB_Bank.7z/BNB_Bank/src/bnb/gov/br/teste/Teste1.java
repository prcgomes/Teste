package bnb.gov.br.teste;

public class Teste1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Stub de m�todo gerado automaticamente
		long x1 = 9223372036854775807l;
		long x2 = 9223371036854775807l;
		System.out.println(x1 +" - "+ x2 +" = "+ (x1-x2));
		float y1 = x1;
		float y2 = x2;
		System.out.println(y1 +" - "+ y2 +" = "+ (y1-y2));

	}

}
