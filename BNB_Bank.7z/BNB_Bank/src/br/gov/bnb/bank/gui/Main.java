package br.gov.bnb.bank.gui;


public class Main {	

		
	public static void main(String[] args) {
		
		GUIBank gui = new GUIBank();
		
		gui.cadastrarClientes();	
		
		gui.cadastrarContas();
				
		gui.renderBonus();
		
		gui.renderJuros();
		
		gui.transferirConta();
		
		gui.transferirPoupanca();
		
		gui.outrosTestes();
		
	}
	
}
