package br.gov.bnb.bank.gui;

import java.util.Observable;
import java.util.Observer;

import br.gov.bnb.bank.exceptions.ErroAcessoRepositorioException;
import br.gov.bnb.bank.negocio.Cliente;
import br.gov.bnb.bank.negocio.Conta;
import br.gov.bnb.bank.negocio.ContaAbstrata;
import br.gov.bnb.bank.negocio.ContaBonificada;
import br.gov.bnb.bank.negocio.Endereco;
import br.gov.bnb.bank.negocio.Fachada;
import br.gov.bnb.bank.negocio.Poupanca;
import br.gov.bnb.bank.negocio.TipoCliente;


public class GUIBank implements Observer{

		public Cliente cliente1 = new Cliente("000.000.000-00", "Z�",   new Endereco("60000", "Rua Santos Dumont", "Aldeota", "AP 1"), TipoCliente.CLASS); ;
		public Cliente cliente2 = new Cliente("111.111.111-11", "S�",   new Endereco("65000", "Rua 24 de Maio", "Centro", "AP 1"), TipoCliente.STANDARD); 
		public Cliente cliente3 = new Cliente("222.222.222-22", "D�",   new Endereco("69000", "Rua 5", "Bom Jardim", "AP 1"), TipoCliente.VIP);	
		public Cliente cliente4 = new Cliente("444.444.444-44", "J�",   new Endereco("62000", "Rua 2", "Montese", "AP 10"), TipoCliente.STANDARD); 
		public Cliente cliente5 = new Cliente("555.555.555-55", "Di",   new Endereco("68000", "Rua 25", "Parquelandia", "AP 15"), TipoCliente.VIP);	
		
		public ContaAbstrata conta1 = new Conta("1001",0, cliente1);
		public ContaAbstrata conta2 = new Conta("2002",0, cliente2);
		public ContaAbstrata conta3 = new Conta("3003",0, cliente3);
		public ContaAbstrata conta4 = new ContaBonificada("4004",0, cliente4); 
		public ContaAbstrata conta5 = new Poupanca("5005",400, cliente5);
			
		public Fachada fachada;	
		
		
		public GUIBank() {
			
			fachada = Fachada.obterInstancia();			
		
		}
		
		
		public void cadastrarClientes(){
			
			System.out.println("Cadastrar clientes:");			
			try {
				
				fachada.cadastrarCliente(cliente1);
				fachada.cadastrarCliente(cliente2);
				fachada.cadastrarCliente(cliente3);	
				fachada.cadastrarCliente(cliente4);
				fachada.cadastrarCliente(cliente5);		
				
			} catch (ErroAcessoRepositorioException e) {			 
				System.out.println(e.getMessage());
			}		
			fachada.listarClientes();
			
			
			
			System.out.println("\nRemover cliente 222.222.222-22:");
			try {
				
				fachada.descadastrarCliente(cliente3.getCPF());
				
			} catch (ErroAcessoRepositorioException e) {			
				System.out.println(e.getMessage());
			}		
			fachada.listarClientes();
			
			
			
			System.out.println("\nInserir cliente 222.222.222-22:");
			try {
				
				fachada.cadastrarCliente(cliente3);
				
			} catch (ErroAcessoRepositorioException e) {			
				System.out.println(e.getMessage());
			}
			fachada.listarClientes();
				
			
			
			System.out.println("\nAtualizar CEP do 222.222.222-22:");
			cliente3.getEndereco().setCEP("70000");
			try {
				
				fachada.atualizarCliente(cliente3);
				
			} catch (ErroAcessoRepositorioException e) {			
				System.out.println(e.getMessage());
			}		
			fachada.listarClientes();
		}
		
		public void cadastrarContas(){
			
			System.out.println("\n\nCriar contas:");
						
			try {
				fachada.cadastrarConta(conta1);
				fachada.cadastrarConta(conta2);
				fachada.cadastrarConta(conta3);
				fachada.cadastrarConta(conta4);
				fachada.cadastrarConta(conta5);
				
			} catch (ErroAcessoRepositorioException e) {
				
				System.out.println(e.getMessage());
			}
			
			fachada.listarContas();
					
			
			
			System.out.println("\nRemover conta 3003:");
			try {
				
				fachada.removerConta(conta3.getNumero());
				
			} catch (ErroAcessoRepositorioException e) {
				
				System.out.println(e.getMessage());
			}
			fachada.listarContas();		
			
			
			
			System.out.println("\nInserir conta 3003:");
			try {
				fachada.cadastrarConta(conta3);
			} catch (ErroAcessoRepositorioException e) {
				
				System.out.println(e.getMessage());
			} 
			fachada.listarContas();
			
			
			
			System.out.println("\nAtualizar conta 3003:");
			try {
				
				conta3.setSaldo(1000);
				fachada.atualizarConta(conta3);
				
			} catch (ErroAcessoRepositorioException e) {
				System.out.println(e.getMessage());
			}		
			fachada.listarContas();		
		}
		
		public void renderBonus(){
					
			System.out.println("\n\nCCreditar 100.0 a Conta Bonificada");
			((ContaBonificada) conta4).creditar(100.0);
			fachada.listarContas();
			System.out.println("\nRender B�nus");
			if(conta4 instanceof ContaBonificada){			
				((ContaBonificada) conta4).renderBonus();
			}
			fachada.listarContas();
		}
		
		public void renderJuros(){
							
			System.out.println("\nCriar conta poupanca creditando 400.0");
			fachada.listarContas();
			System.out.println("\nRender Juros");
			if(conta5 instanceof Poupanca){
				((Poupanca) conta5).renderJuros(0.005);
			}
			fachada.listarContas();		
		}
		
		/*********Transferir 200 conta 3003 para conta 2002*********/
		public void transferirConta(){

			System.out.println("\n\nTransferir 200 da conta 3003 para conta 2002");
			ContaAbstrata contaDebitada  = fachada.procurarConta("3003");
			ContaAbstrata contaCreditada = fachada.procurarConta("2002");
			try {
				if (contaDebitada == null || contaCreditada == null) throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("contaInexistente"));
				contaDebitada.transferir(contaCreditada, 200.0);
			} catch (ErroAcessoRepositorioException e) {
				System.out.println(e.getMessage());
			} 
			fachada.listarContas();		
		}
		
		/*********Transferir 300 de conta Poupanca para conta Bonificada*********/
		public void transferirPoupanca(){		
			
			System.out.println("\n\nTransferir 300 de conta Poupanca para conta Bonificada");
			ContaAbstrata contaPoupancaDebitada    = fachada.procurarConta("5005");
			ContaAbstrata contaBonificadaCreditada = fachada.procurarConta("4004");
			try {
				if (contaPoupancaDebitada == null || contaBonificadaCreditada == null) throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("contaInexistente"));
				
				contaPoupancaDebitada.transferir(contaBonificadaCreditada, 300.0);
			} catch (ErroAcessoRepositorioException e) {
				System.out.println(e.getMessage());
			} 
			fachada.listarContas();
		}	
		
		public void outrosTestes(){
			
			//cadastrar cliente j� existente
			System.out.println("\n\nCadastrar cliente existente");
			try {
				
				fachada.cadastrarCliente(cliente1);
				
			} catch (ErroAcessoRepositorioException e) {			 
				System.out.println(e.getMessage());
			} 
			
			//cadastrar conta j� existente
			System.out.println("\n\nCadastrar conta existente");
			try {
				fachada.cadastrarConta(conta1);
			} catch (ErroAcessoRepositorioException e) {
				System.out.println(e.getMessage());
			} 
			
			System.out.println("\n\nAtualizar cliente nulo:");
			try {
				fachada.atualizarCliente(null);
			} catch (ErroAcessoRepositorioException e) {
				System.out.println(e.getMessage());
			}
			
			System.out.println("\n\nRemover cliente de conta, tentar recadastrar conta sem cliente:");
			try {
				
				fachada.removerConta("1001");
				conta1.setCliente(null);
				fachada.cadastrarConta(conta1);
				
			} catch (ErroAcessoRepositorioException e) {
				System.out.println(e.getMessage());
			} 	
		}


		@Override
		public void update(Observable arg0, Object arg1) {
			// TODO Auto-generated method stub
			
		}
	}
