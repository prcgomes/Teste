package br.gov.bnb.bank.dados;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import br.gov.bnb.bank.negocio.ContaAbstrata;

public class RepositorioContasMap implements IRepositorioContas {

	private Map<String, ContaAbstrata> contas;
	
	public RepositorioContasMap() {
		
		contas = new HashMap<String, ContaAbstrata>();
	}
	
	@Override
	public void atualizar(ContaAbstrata c) {

		ContaAbstrata conta = this.contas.get(c.getNumero());
		if(conta != null){
			this.contas.remove(conta.getNumero());
			this.contas.put(c.getNumero(), c);
		}	
	}

	@Override
	public boolean existe(String num) {
		
		if(this.contas.containsKey(num)){
			return true;
		}
		else{			
			return false;
		}			
	}

	public Collection<ContaAbstrata> getContas() {
		
		return this.contas.values();
	}

	@Override
	public void inserir(ContaAbstrata c) {

		contas.put(c.getNumero(), c);		
	}

	@Override
	public ContaAbstrata procurar(String num) {

		if(this.contas.containsKey(num)){
			return this.contas.get(num);
		}
		
		return null;
	}

	@Override
	public void remover(ContaAbstrata c) {
		
		ContaAbstrata conta = this.contas.get(c.getNumero());
		if(conta != null){
			this.contas.remove(conta.getNumero());			
		}			
	}
}
