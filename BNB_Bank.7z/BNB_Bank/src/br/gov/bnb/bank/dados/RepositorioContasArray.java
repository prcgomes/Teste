package br.gov.bnb.bank.dados;
import java.util.ArrayList;
import java.util.Collection;

import br.gov.bnb.bank.negocio.ContaAbstrata;
import br.gov.bnb.bank.negocio.Fachada;


public class RepositorioContasArray implements IRepositorioContas {

	public static final int TAM_CACHE_CONTAS = Integer.parseInt(Fachada.sistemaProperties.getProperty("tamArray"));
	private ContaAbstrata []contas;
	private int indice;
	
	public RepositorioContasArray() {
		
		this.contas = new ContaAbstrata[TAM_CACHE_CONTAS];					
	}	
	
	public void inserir(ContaAbstrata conta){
							
		for (int i = 0; i < this.contas.length; i++) {
			
			if(this.contas[i] == null){
				this.contas[i] = conta;
				break;
			}			
		}		
	}	
	
	public void atualizar (ContaAbstrata conta){
						
		this.indice = procurarIndice(conta.getNumero()); 
		this.contas[this.indice] = conta;		
	}
	
	public void remover(ContaAbstrata conta){
							
		this.indice = procurarIndice(conta.getNumero());
		this.contas[this.indice] = null;						
	}
	
	private int procurarIndice(String numeroConta){
		
		int i = 0;		
		
		for (ContaAbstrata c : this.contas) {
			
			if(c!=null && c.getNumero().equals(numeroConta)){
				
				return i;				
			}		
			i++;
		}
		
		return -1;
	}
	
	public boolean existe(String numeroConta){
		
		if(procurar(numeroConta)!= null){
			return true;
		}
		else{			
			return false;
		}	
	}
	
	public ContaAbstrata procurar(String numeroConta){
		
		for (ContaAbstrata c : this.contas) {
			
			if(c!=null && c.getNumero().equals(numeroConta)){
				
				return c;
			}			
		}
		return null;
	}	
	
	public Collection<ContaAbstrata> getContas() {
		
		Collection<ContaAbstrata> col = new ArrayList<ContaAbstrata>();
		for (ContaAbstrata c : this.contas){
			col.add(c);
		}
		
		return col;	
	}
}
