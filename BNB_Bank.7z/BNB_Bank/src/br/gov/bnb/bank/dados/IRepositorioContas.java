package br.gov.bnb.bank.dados;

import java.util.Collection;

import br.gov.bnb.bank.negocio.ContaAbstrata;

public interface IRepositorioContas extends IRepositorio<ContaAbstrata>{
		
	public Collection<ContaAbstrata> getContas();
	
}
