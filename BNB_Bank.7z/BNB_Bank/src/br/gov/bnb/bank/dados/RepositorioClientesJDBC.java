package br.gov.bnb.bank.dados;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collection;

import br.gov.bnb.bank.negocio.Cliente;
import br.gov.bnb.bank.util.JDBCConnectionUtil;

public class RepositorioClientesJDBC implements IRepositorioClientes{

	@Override
	public Collection<Cliente> getClientes() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void atualizar(Cliente t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean existe(String t) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void inserir(Cliente t) {

		String sql = JdbcUtil.lerSQL()
		
	}

	@Override
	public Cliente procurar(String t) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remover(Cliente t) {
		// TODO Auto-generated method stub
		
	}
	
	private ResultSet getResultSet(String query){
		
		Connection connection = null;
		Statement st = null;
		ResultSet rs = null;
		
		try {			
			
			connection  = JDBCConnectionUtil.getConnection();
			st = connection.createStatement();
			rs = st.executeQuery(query);
			
			
			/*while(rs.next()){
				System.out.println(rs.getString("CPF"));
				System.out.println(rs.getString("NOME"));
			}*/		
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			
			try {
				st.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		
		return rs;	
	}
}
