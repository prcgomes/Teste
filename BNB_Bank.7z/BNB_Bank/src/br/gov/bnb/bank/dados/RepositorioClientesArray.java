package br.gov.bnb.bank.dados;
import java.util.ArrayList;
import java.util.Collection;

import br.gov.bnb.bank.negocio.Cliente;
import br.gov.bnb.bank.negocio.Fachada;


public class RepositorioClientesArray implements IRepositorioClientes{

	public static final int TAM_CACHE_CLIENTES = Integer.parseInt(Fachada.sistemaProperties.getProperty("tamArray"));
	private Cliente[]clientes;
	private int indice;
	
	public RepositorioClientesArray() {
		
		this.clientes = new Cliente[TAM_CACHE_CLIENTES];					
	}	
	
	public void inserir(Cliente cliente){
					
		for (int i = 0; i < this.clientes.length; i++) {
			
			if(this.clientes[i] == null){
				this.clientes[i] = cliente;					
				break;
			}			
		}		
	}	
	
	public void atualizar (Cliente cliente){
								
		this.indice = procurarIndice(cliente.getCPF()); 
		this.clientes[this.indice] = cliente;				
	}
	
	public void remover(Cliente cliente){	
			
		this.indice = procurarIndice(cliente.getCPF());
		this.clientes[this.indice] = null;				
	}
	
	private int procurarIndice(String cpf){
		
		int i = 0;		
		
		for (Cliente c : this.clientes) {
			
			if(c!=null && c.getCPF().equals(cpf)){
				
				return i;				
			}		
			i++;
		}
		
		return -1;
	}
	
	public boolean existe(String cpf){
		
		if(procurar(cpf)!= null){
			return true;
		}
		else{			
			return false;
		}	
	}
	
	public Cliente procurar(String cpf){
		
		for (Cliente c : this.clientes) {
			
			if(c!=null && c.getCPF().equals(cpf)){
				
				return c;
			}			
		}
		return null;
	}
	
	public Collection<Cliente> getClientes() {
		
		Collection<Cliente> col = new ArrayList<Cliente>();
		for (Cliente cli : this.clientes){
			col.add(cli);
		}
		return col;
	}	
}
