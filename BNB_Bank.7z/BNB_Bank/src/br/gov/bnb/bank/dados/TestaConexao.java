package br.gov.bnb.bank.dados;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestaConexao {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {
			
			Class.forName("org.hsqldb.jdbcDriver");
			
			Connection con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost:9090/qib", "sa", "");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from tb_cliente");
			
			while(rs.next()){
				System.out.println(rs.getString("CPF"));
				System.out.println(rs.getString("NOME"));
			}
			
			
			
			con.close();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
