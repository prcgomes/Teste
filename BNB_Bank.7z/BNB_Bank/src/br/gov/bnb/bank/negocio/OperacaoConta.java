package br.gov.bnb.bank.negocio;

public enum OperacaoConta {

	CREDITAR,
	DEBITAR,
	BONUS,
	IMPOSTO
}
