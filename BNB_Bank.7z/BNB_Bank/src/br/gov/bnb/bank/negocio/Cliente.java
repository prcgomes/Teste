package br.gov.bnb.bank.negocio;

import java.util.Collection;

public class Cliente implements Comparable<Cliente>{

	private String CPF;	
	private String nome;
	private Endereco endereco;
	private TipoCliente tipo;
	private Collection<Gerente> gerentes;
	
	public Cliente(String cpf, String nome, Endereco endereco, TipoCliente tipo) {

		setCPF(cpf);
		setNome(nome);
		setEndereco(endereco);
		setTipo(tipo);		
	}
	
	public String getCPF() {
		return CPF;
	}
	
	public void setCPF(String cpf) {
		CPF = cpf;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public Endereco getEndereco() {
		return endereco;
	}
	
	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	
	public TipoCliente getTipo() {
		return tipo;
	}
	
	public void setTipo(TipoCliente tipo) {
		this.tipo = tipo;
	}

	public int compareTo(Cliente c) {		 
		return this.nome.compareTo(c.getNome());
	}
	
	public String toString() {		
		return this.getNome();
	}
	
}
