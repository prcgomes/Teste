package br.gov.bnb.bank.negocio;

import br.gov.bnb.bank.exceptions.ErroAcessoRepositorioException;

public class ContaImposto extends ContaAbstrata{


	public static final double TAXA = 0.001; //0,1%

	public ContaImposto (String n, Cliente c) {
		
		super (n,c);
	}

	public void debitar(double valor) throws ErroAcessoRepositorioException {
		
		double imposto = valor * TAXA;
		double saldo = this.getSaldo();
		
		if (valor + imposto <= saldo) {
			setSaldo(saldo - (valor + imposto));
			notifyObservers(OperacaoConta.IMPOSTO);
		} 
		else {
			throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("saldoInsuficiente"));
		}
	}
}
