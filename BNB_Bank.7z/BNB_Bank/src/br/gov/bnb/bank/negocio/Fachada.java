package br.gov.bnb.bank.negocio;

import java.io.FileInputStream;
import java.util.Properties;

import br.gov.bnb.bank.dados.RepositorioClientesArray;
import br.gov.bnb.bank.dados.RepositorioClientesFile;
import br.gov.bnb.bank.dados.RepositorioClientesJDBC;
import br.gov.bnb.bank.dados.RepositorioClientesSet;
import br.gov.bnb.bank.dados.RepositorioContasArray;
import br.gov.bnb.bank.dados.RepositorioContasMap;
import br.gov.bnb.bank.exceptions.ErroAcessoRepositorioException;


public class Fachada {
	
	private static Fachada instancia;
	private CadastroClientes clientes;
	private CadastroContas contas;
	public static Properties sistemaProperties;
	public static Properties exceptionsProperties;
	
	static{
		
		try{			
			sistemaProperties = new Properties();			
			//carregou o arquivo de propriedades para o sistema
			sistemaProperties.load(new FileInputStream("sistema.properties"));
			
			exceptionsProperties = new Properties();			
			exceptionsProperties.load(new FileInputStream("exceptions.properties"));			
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	public static Fachada obterInstancia() {
		
		if (instancia == null){
			instancia = new Fachada();
		}
		return instancia;		
	}
	
	private Fachada(){		
		initCadastro();		
	}
	
	private void initCadastro(){
		//TODO designpattern
		String tipoRepo = sistemaProperties.getProperty("tipoRepositorio");
		int tipo = Integer.parseInt(tipoRepo);
		
		switch (tipo) {
		//Array
		case 1:
			clientes = new CadastroClientes(new RepositorioClientesArray());
			contas   = new CadastroContas(new RepositorioContasArray());
			break;
		//Collection
		case 2:
			clientes = new CadastroClientes(new RepositorioClientesSet());
			contas   = new CadastroContas(new RepositorioContasMap());
			break;
		//File
		case 3:
			clientes = new CadastroClientes(new RepositorioClientesFile());
			//contas   = new CadastroContas(new RepositorioContasFile());
			break;
		case 4: 
			clientes = new CadastroClientes(new RepositorioClientesJDBC());	
		 	break;
			
		default:
			
			break;
		}
		
		
		//clientes = new CadastroClientes(new RepositorioClientesFile());
		//contas   = new CadastroContas(new RepositorioContasMap());
	}
	
	//metodos para manipular clientes
	public void atualizarCliente(Cliente c) throws ErroAcessoRepositorioException{
		
		clientes.atualizar(c);
	}
	
	public Cliente procurarCliente(String cpf){
		
		return clientes.procurar(cpf);
	}
	
	public void cadastrarCliente(Cliente c) throws ErroAcessoRepositorioException{
		
		clientes.cadastrar(c);
	}
	
	public void descadastrarCliente(String cpf) throws ErroAcessoRepositorioException{
		
		clientes.descadastrar(cpf);
	}
	
	//metodos para manipular contas
	public void atualizarConta(ContaAbstrata c) throws ErroAcessoRepositorioException{
						
		contas.atualizar(c);		
	}
	
	public ContaAbstrata procurarConta(String n) {
		
		return contas.procurar(n);
	}
	
	public void cadastrarConta(ContaAbstrata c) throws ErroAcessoRepositorioException{
		
		if(c != null){
			
			Cliente cli = c.getCliente();
			if (cli != null) {
				
				if (clientes.procurar(cli.getCPF()) != null){
					contas.cadastrar(c);
				}
				else{
					throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("clienteNaoCadastrado"));
				}					
			} 
			else {				
				throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("contaSemCliente"));
			}
		}
		else{
			throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("contaNula"));
		}
	}

	public void removerConta(String n) throws ErroAcessoRepositorioException {
		
		contas.descadastrar(n);
	}
	
	public void creditar(String n, double v) throws ErroAcessoRepositorioException {
		
		contas.creditar(n, v);
	}
	
	public void debitar(String n, double v) throws ErroAcessoRepositorioException {
		
		contas.debitar(n, v);
	}
	
	public void transferir(String origem, String destino, double val) throws ErroAcessoRepositorioException{
		
		contas.transferir(origem, destino, val);
	}	
	
	public void listarClientes(){
		
		clientes.listar();
	}
	
	public void listarContas(){
		
		contas.listar();
	}
}
