package br.gov.bnb.bank.negocio;
import br.gov.bnb.bank.dados.IRepositorioContas;
import br.gov.bnb.bank.exceptions.ErroAcessoRepositorioException;

public class CadastroContas implements ICadastro<ContaAbstrata>{

	private IRepositorioContas contas;
		
	public CadastroContas(IRepositorioContas r) {
		
		this.contas = r;
	}
	
	public void atualizar(ContaAbstrata c) throws ErroAcessoRepositorioException{
		
		if (c == null){ throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("contaNula"));}
		
		if(existe(c.getNumero())){
			contas.atualizar(c);
		}
		else{
			
			throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("contaInexistente"));			
		}
	}	
	
	public void cadastrar(ContaAbstrata c) throws ErroAcessoRepositorioException{
		
		if (c == null){ throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("contaNula"));}
		
		if (!existe(c.getNumero())){
			
			contas.inserir(c);			
		}
		else{
			
			throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("contaExistente"));			
		}		
	}
	
	public void creditar(String n, double v) throws ErroAcessoRepositorioException{
		
		ContaAbstrata c = procurar(n);
		
		if (c != null){
			
			c.creditar(v);
			atualizar(c);
		}
		else{
		
			throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("contaNula"));
		}				
	}
	
	public void debitar(String n, double v) throws ErroAcessoRepositorioException{
		
		ContaAbstrata c = contas.procurar(n);
		
		if (c != null){
			
			c.debitar(v);
			contas.atualizar(c);
		}
		else{
		
			throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("contaNula"));
		}					
	}
	
	public void transferir(String origem, String destino, double valor) throws ErroAcessoRepositorioException{
		
		ContaAbstrata o = contas.procurar(origem);
		ContaAbstrata d = contas.procurar(destino);
		
		if(o == null){
			throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("contaOrigemInexistente"));
		} else if(d == null){			
			throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("contaDestinoInexistente"));
		}
		else{			
			o.transferir(d, valor);
			atualizar(o);
			atualizar(d);		
		}
	}
	
	public void descadastrar(String n) throws ErroAcessoRepositorioException{
		
		if(existe(n)){
			ContaAbstrata c = procurar(n);
			contas.remover(c);	
		}
		else{
			throw new ErroAcessoRepositorioException(Fachada.exceptionsProperties.getProperty("contaInexistente"));
		}
	}
	public boolean existe(String n){
		
		return contas.existe(n);
	}
	
	public ContaAbstrata procurar(String n){
		
		return contas.procurar(n);
	}
	
	public void listar(){
		
		for (ContaAbstrata c : contas.getContas()) {
			
			if(c!=null){
				
				System.out.println("Conta "+ c.getNumero() +" Saldo: " + c.getSaldo());
			}			
		}		
	}	
}
