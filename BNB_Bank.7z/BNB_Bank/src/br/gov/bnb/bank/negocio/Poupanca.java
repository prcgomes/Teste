package br.gov.bnb.bank.negocio;


public class Poupanca extends Conta {

	public Poupanca(String numero, Cliente c) {
		super(numero, c);
	}

	public Poupanca(String numero, double valor, Cliente c) {
		super(numero, valor, c);
	}
	
	public void renderJuros(double taxa){
		
		double saldoAtual = getSaldo();
		creditar(saldoAtual*taxa);		
	}
}
