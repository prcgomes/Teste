package br.gov.bnb.bank.negocio;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

import br.gov.bnb.bank.exceptions.ErroAcessoRepositorioException;

public abstract class ContaAbstrata extends Observable{


	private String numero;
	private double saldo;
	private Cliente cliente;
	private ArrayList<Observer> observers;
	
	public ContaAbstrata(String num, Cliente c) {
		numero = num;
		cliente = c;
		saldo = 0;
		observers = new ArrayList<Observer>();
	}
	
	public ContaAbstrata(String num, double s, Cliente c) {
		numero = num;
		saldo = s;
		cliente = c;
	}
	
	public Cliente getCliente(){
		return cliente;
	}
	
	public String getNumero() {
		return numero;
	}
	
	public double getSaldo() {
		return saldo;
	}
	
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	
	public void setNumero(String num) {
		this.numero = num;
	}
	
	public void setSaldo(double valor) {
		saldo = valor;
	}
	public void creditar(double valor){
		saldo = saldo + valor;
		notifyObservers(OperacaoConta.CREDITAR);
	}
	
	public abstract void debitar(double valor) throws ErroAcessoRepositorioException;
	
	public void transferir(ContaAbstrata c, double v) throws ErroAcessoRepositorioException{
		
		this.debitar(v);		
		c.creditar(v);
	}	
	
	@Override
	public void addObserver(Observer arg0) {
		// TODO Auto-generated method stub
		this.observers.add(arg0);
	}

	@Override
	public synchronized void deleteObserver(Observer arg0) {
		// TODO Auto-generated method stub
		this.observers.remove(arg0);
	}

	@Override
	public void notifyObservers(Object arg0) {
		// TODO Auto-generated method stub
		for (Observer observer : this.observers) {
			
			observer.update(this, arg0);			
		}
	}
}
