package br.gov.bnb.bank.exceptions;

@Deprecated
public class SaldoInsuficienteException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5344588298694099554L;

	public SaldoInsuficienteException(String msg) {
		super(msg);
	}
}
