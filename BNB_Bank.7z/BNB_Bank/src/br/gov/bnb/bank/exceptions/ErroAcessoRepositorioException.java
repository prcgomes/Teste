package br.gov.bnb.bank.exceptions;

public class ErroAcessoRepositorioException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ErroAcessoRepositorioException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	

}
