package br.gov.bnb.bank.exceptions;

@Deprecated
public class ClienteExistenteException extends Exception {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2569683438155234907L;

	public ClienteExistenteException(String msg) {
		super(msg);
	}
}
