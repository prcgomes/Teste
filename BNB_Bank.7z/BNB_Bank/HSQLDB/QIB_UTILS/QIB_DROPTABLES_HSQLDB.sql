DROP TABLE tb_gerentes_cliente;
DROP TABLE tb_endereco;
DROP TABLE tb_conta;
DROP TABLE tb_gerente;
DROP TABLE tb_cliente;